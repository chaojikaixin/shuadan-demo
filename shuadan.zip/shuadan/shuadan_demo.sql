/*
 Navicat Premium Data Transfer

 Source Server         : local
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : localhost:3306
 Source Schema         : shuadan_demo

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 07/07/2020 13:43:50
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sd_assets
-- ----------------------------
DROP TABLE IF EXISTS `sd_assets`;
CREATE TABLE `sd_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `templateId` int(11) DEFAULT NULL COMMENT '模板ID',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产图片',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产名称',
  `price` decimal(20,2) DEFAULT NULL COMMENT '资产价值',
  `createTime` datetime DEFAULT NULL COMMENT '创建时间',
  `shopName` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商家名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of sd_assets
-- ----------------------------
BEGIN;
INSERT INTO `sd_assets` VALUES (27, 5, 'http://43.227.199.141:86/api/v1/common/display/2020/06/28/2c011cb844ca45fcbf896d27412b57b7', '【7月3日秋装上新 拍下8.5折85元】长袖条纹衬衣衬衫', 162.00, '2020-06-28 13:51:08', '韩潮袭人旗舰店');
INSERT INTO `sd_assets` VALUES (28, 5, 'http://43.227.199.141:86/api/v1/common/display/2020/06/28/0eb5986bb12947e5967987d2ba2f155a', '讯迪小米10手机壳小米10pro保护套青春版5g硅胶全包防摔气囊米9液态磨砂个性创意十玻璃男pr0软外壳mi超薄por', 32.15, '2020-06-28 13:52:20', '讯迪旗舰店');
INSERT INTO `sd_assets` VALUES (29, 5, 'http://43.227.199.141:86/api/v1/common/display/2020/06/28/34580253a179453dbfc2ac76a6cd5694', '红米k30手机壳液态硅胶redmik30pro', 15.10, '2020-06-28 13:53:17', '果果帮旗舰店');
INSERT INTO `sd_assets` VALUES (30, 5, 'http://43.227.199.141:86/api/v1/common/display/2020/06/28/8f06be8a5afb47cdb94a77b7b3d67b4f', '得力透明胶带 大号宽胶带快递打包封箱带批发封口胶布胶纸大卷封箱胶带宽4.5/6cm胶带封箱带', 1.21, '2020-06-28 13:54:29', '得力立兴伟业专卖店');
INSERT INTO `sd_assets` VALUES (31, 5, 'http://43.227.199.141:86/api/v1/common/display/2020/06/28/6213dc4741df4018a622f288040b82b0', '美纹纸胶带可书写分色胶美文胶带纸胶带不残留手撕纸胶美术生专用贴', 0.54, '2020-06-28 13:55:48', '奔亿达深骏业专卖店');
INSERT INTO `sd_assets` VALUES (32, 5, 'http://43.227.199.141:86/api/v1/common/display/2020/06/28/5b7c13e25e804496a149e742726dd350', '白色花朵蕾丝布贴小号衣服装饰补破洞贴补丁贴花时尚DIY刺绣贴布', 1.58, '2020-06-28 13:58:38', 'wanyu旗舰店');
INSERT INTO `sd_assets` VALUES (33, 5, 'http://43.227.199.141:86/api/v1/common/display/2020/06/28/42385b1dcd60430f87f62c9b51fbe839', '流苏星星图案水钻布贴时尚亮片补衣服装饰补丁贴花小号女熨烫画贴', 1.35, '2020-06-28 14:00:10', 'fastso旗舰店');
INSERT INTO `sd_assets` VALUES (34, 6, 'http://43.227.199.141:86/api/v1/common/display/2020/06/30/9c13ca06df3b481e87d611c7c1bb0546', '九牧王（JOEONE）男装 休闲裤春夏款简约宽松时尚中青年男士休闲裤舒适长裤', 199.90, '2020-06-30 17:56:37', '九牧王旗舰店');
INSERT INTO `sd_assets` VALUES (35, 6, 'http://43.227.199.141:86/api/v1/common/display/2020/06/30/6e9f458b64054c24b6bf1d04fbc3ab2a', '宽松真丝上衣女衬衣中老年桑蚕丝长袖衬衫时尚洋气妈妈穿的春秋衫', 79.90, '2020-06-30 17:58:18', '可可里时尚女装潮');
INSERT INTO `sd_assets` VALUES (36, 6, 'http://43.227.199.141:86/api/v1/common/display/2020/06/30/b20204b59d5849ea9e0d7ac6e1c93bdd', '宽松真丝上衣女衬衣中老年桑蚕丝长袖衬衫时尚洋气妈妈穿的春秋衫', 79.90, '2020-06-30 17:59:22', '可可里时尚女装潮');
INSERT INTO `sd_assets` VALUES (37, 6, 'http://43.227.199.141:86/api/v1/common/display/2020/06/30/4ecee4f42ed94d9ab8d0a588f7c7865e', '2020新款夏季女装短款T恤个性女装', 29.90, '2020-06-30 18:00:19', 'BEG女装店');
INSERT INTO `sd_assets` VALUES (38, 6, 'http://43.227.199.141:86/api/v1/common/display/2020/06/30/6a834cde73b24b9aaf28f4bdfb1d28bc', '2020夏季新款女装气质休闲雪纺连衣裙中长款少女风气质连衣裙长款', 185.00, '2020-06-30 18:01:06', 'LETOOU乐淘');
INSERT INTO `sd_assets` VALUES (39, 6, 'http://43.227.199.141:86/api/v1/common/display/2020/06/30/72f94ab4a3ad43938793c42783a6e203', 'D003 2020新款夏季白色t恤女短袖宽松百搭T恤女韩版学生女装', 9.90, '2020-06-30 18:02:37', '欣欣服装店铺$');
INSERT INTO `sd_assets` VALUES (40, 6, 'http://43.227.199.141:86/api/v1/common/display/2020/06/30/45ab37d7307a429c9b4f35d1176016db', '夏季新款大码女装胖mm法式衬衫连衣裙显瘦女神范职业气质休闲裙子', 168.00, '2020-06-30 18:03:54', '聚美优3号店');
INSERT INTO `sd_assets` VALUES (41, 6, 'http://43.227.199.141:86/api/v1/common/display/2020/06/30/95151b988bb14b538fa7fbfe994812d7', '美缝吸尘器家用强力小型大吸力干湿两用工业车用装修吸尘机大功率', 88.00, '2020-06-30 18:05:40', '红心海众专卖店');
INSERT INTO `sd_assets` VALUES (42, 6, 'http://43.227.199.141:86/api/v1/common/display/2020/06/30/a0d8296f832e423e8038563ccd645b03', 'LED台灯护眼书桌学生写字学习专用宿舍充电插电两用卧室床头工作', 49.00, '2020-06-30 18:06:37', '赛德丽旗舰店');
INSERT INTO `sd_assets` VALUES (43, 6, 'http://43.227.199.141:86/api/v1/common/display/2020/06/30/ad35615105864f1f8d3272953eaa13a9', '北欧台灯卧室床头灯简约现代感应灯温馨浪漫遥控可调光触摸床头柜', 118.00, '2020-06-30 18:08:06', 'jue670');
INSERT INTO `sd_assets` VALUES (44, 6, 'http://43.227.199.141:86/api/v1/common/display/2020/06/30/71fe5bd2ebfc4490a957befad2876baa', '湖鑫车载风扇12V24V小电风扇大货车面包车车用制冷伏汽车内吸盘式', 89.00, '2020-06-30 18:09:16', '湖鑫旗舰店');
INSERT INTO `sd_assets` VALUES (45, 6, 'http://43.227.199.141:86/api/v1/common/display/2020/06/30/dbf93ffe618843eeb0faf51afb678ba4', '临时停车号码牌挪车电话移车牌高档汽车用品创意夜光手机车载双卡', 68.00, '2020-06-30 18:10:11', '菁创数码专营店');
INSERT INTO `sd_assets` VALUES (46, 6, 'http://43.227.199.141:86/api/v1/common/display/2020/06/30/89546224a70a4ef3bbef17eeedb0b44c', '奇瑞新款艾瑞泽5专用汽车衣车罩防晒防雨遮阳加厚牛津布盖车外套', 55.00, '2020-06-30 18:11:26', '卡加尼车品旗舰店');
INSERT INTO `sd_assets` VALUES (47, 6, 'http://43.227.199.141:86/api/v1/common/display/2020/06/30/4eb7d963495a4cfd963eb57fdbc3b3a2', '儿童扭扭车防侧翻宝宝静音万向轮滑行大人可坐妞妞摇摆滑滑溜溜车', 99.00, '2020-06-30 18:12:49', '明爵旗舰店');
COMMIT;

-- ----------------------------
-- Table structure for sd_assets_order
-- ----------------------------
DROP TABLE IF EXISTS `sd_assets_order`;
CREATE TABLE `sd_assets_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderNo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单号',
  `templateId` int(11) DEFAULT NULL COMMENT '模板ID',
  `assetsId` int(11) DEFAULT NULL COMMENT '资产ID',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产名称',
  `templateName` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '模板名称',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产图片',
  `price` decimal(20,2) DEFAULT NULL COMMENT '资产单价',
  `allPrice` decimal(20,2) DEFAULT NULL COMMENT '资产总价',
  `newMoney` decimal(20,2) DEFAULT NULL COMMENT '收益金额',
  `count` int(11) DEFAULT NULL COMMENT '资产数量',
  `createTime` datetime DEFAULT NULL COMMENT '订单创建时间',
  `checkTime` datetime DEFAULT NULL COMMENT '订单确认时间',
  `userId` int(11) DEFAULT NULL COMMENT '所属用户ID',
  `frozen` int(1) DEFAULT NULL COMMENT '是否冻结',
  `del` int(1) DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for sd_assets_template
-- ----------------------------
DROP TABLE IF EXISTS `sd_assets_template`;
CREATE TABLE `sd_assets_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `templateIcon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '模板图标',
  `templateName` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '模板名称',
  `templateMinMoney` decimal(20,2) DEFAULT NULL COMMENT '访问最低限额',
  `templateProfit` decimal(4,1) DEFAULT NULL COMMENT '返现比例',
  `status` int(1) DEFAULT NULL COMMENT '0=正常,1=停用',
  `createTime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of sd_assets_template
-- ----------------------------
BEGIN;
INSERT INTO `sd_assets_template` VALUES (5, 'http://43.227.199.141:86/api/v1/common/display/2020/06/28/08d8f0dbbf634c9fa359d476a71b2999', '拼多多', 100.00, 3.2, 0, '2020-06-28 13:47:01');
INSERT INTO `sd_assets_template` VALUES (6, 'http://43.227.199.141:86/api/v1/common/display/2020/06/28/81e7625d858a4629a9c3ec2e823a4cea', '淘宝', 10000.00, 3.7, 0, '2020-06-28 13:47:32');
INSERT INTO `sd_assets_template` VALUES (7, 'http://43.227.199.141:86/api/v1/common/display/2020/06/28/02940a883b5b4afa81bf6d368dbe5b99', '唯品会', 50000.00, 5.3, 0, '2020-06-28 13:47:54');
INSERT INTO `sd_assets_template` VALUES (8, 'http://43.227.199.141:86/api/v1/common/display/2020/06/28/e026c758f22549949dfea9ddbd198eef', '京东', 100000.00, 7.2, 0, '2020-06-28 13:48:23');
COMMIT;

-- ----------------------------
-- Table structure for sd_bank
-- ----------------------------
DROP TABLE IF EXISTS `sd_bank`;
CREATE TABLE `sd_bank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '类型, wechat=微信, alipay=支付宝, bank=银行卡',
  `accountBank` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '账户开户行',
  `account` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收款账户',
  `accountName` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收款人单位或姓名',
  `createTime` datetime DEFAULT NULL COMMENT '创建时间',
  `status` int(1) DEFAULT NULL COMMENT '0=启用,1=停用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for sd_chat_image
-- ----------------------------
DROP TABLE IF EXISTS `sd_chat_image`;
CREATE TABLE `sd_chat_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL COMMENT '用户ID',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图片地址',
  `createTime` datetime DEFAULT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for sd_message
-- ----------------------------
DROP TABLE IF EXISTS `sd_message`;
CREATE TABLE `sd_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '消息标题',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '消息内容',
  `createTime` datetime DEFAULT NULL,
  `sendToUserId` int(11) DEFAULT NULL COMMENT '接收用户ID',
  `readed` int(1) DEFAULT NULL COMMENT '是否已读',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for sd_order_create
-- ----------------------------
DROP TABLE IF EXISTS `sd_order_create`;
CREATE TABLE `sd_order_create` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for sd_recharge
-- ----------------------------
DROP TABLE IF EXISTS `sd_recharge`;
CREATE TABLE `sd_recharge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL COMMENT '用户ID',
  `bankId` int(11) DEFAULT NULL COMMENT '渠道ID(银行卡ID)',
  `money` decimal(20,2) DEFAULT '0.00' COMMENT '充值金额',
  `bankName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收款开户银行名称',
  `account` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收款银行卡号或二维码',
  `payImage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付凭证',
  `createTime` datetime DEFAULT NULL COMMENT '创建时间',
  `status` int(11) DEFAULT '0' COMMENT '0 = 已提交， 1=已通过， 2=已驳回',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for sd_sys_setting
-- ----------------------------
DROP TABLE IF EXISTS `sd_sys_setting`;
CREATE TABLE `sd_sys_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sysName` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '系统名称',
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '系统图标地址',
  `moneyName` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '金钱名称',
  `newMoneyName` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '当日汇总金钱名称',
  `returnMoneyName` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分红金钱名称',
  `assetsUnit` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产单位名称',
  `assetsName` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产名称',
  `robName` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '抢单动作名称',
  `frozenName` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '金钱冻结名称',
  `oneReturnReward` decimal(10,2) DEFAULT NULL COMMENT '一代团队提成比例',
  `twoReturnReward` decimal(10,2) DEFAULT NULL COMMENT '二代团队提成比例',
  `threeReturnReward` decimal(10,2) DEFAULT NULL COMMENT '三代团队提成比例',
  `robStatus` int(1) DEFAULT NULL COMMENT '抢单开关',
  `regStatus` int(1) DEFAULT NULL COMMENT '注册开关',
  `dscp` text COLLATE utf8mb4_unicode_ci COMMENT '规则介绍',
  `probability` int(3) DEFAULT NULL COMMENT '几率',
  `robCount` int(10) DEFAULT NULL COMMENT '单数数量',
  `startTime` time DEFAULT NULL COMMENT '开始时间',
  `endTime` time DEFAULT NULL COMMENT '结束时间',
  `minRechargeMoney` decimal(20,2) DEFAULT NULL COMMENT '起充金额',
  `testMoney` decimal(20,2) DEFAULT '0.00' COMMENT '体验金额',
  `roomMessage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '聊天室欢迎语',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for sd_user
-- ----------------------------
DROP TABLE IF EXISTS `sd_user`;
CREATE TABLE `sd_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户名',
  `phone` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `nicker` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户头像',
  `money` decimal(20,2) DEFAULT NULL COMMENT '用户账户余额',
  `testMoney` decimal(20,2) DEFAULT NULL COMMENT '体验金',
  `newMoney` decimal(20,2) DEFAULT NULL COMMENT '今日收益',
  `frozenMoney` decimal(20,2) DEFAULT '0.00' COMMENT '冻结金额',
  `returnMoney` decimal(20,2) DEFAULT '0.00' COMMENT '今日分红',
  `name` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '真实姓名',
  `idcard` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '身份证号',
  `idCardImg1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '身份证正面',
  `idCardImg2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '身份证反面',
  `password` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '登录密码',
  `parentId` int(11) DEFAULT NULL COMMENT '上级ID',
  `createTime` datetime DEFAULT NULL COMMENT '注册时间',
  `robCount` int(11) DEFAULT NULL COMMENT '当日已抢单数',
  `status` int(1) DEFAULT NULL COMMENT '0 = 正常, 1 = 禁封',
  `roleType` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ADMIN = 管理员, USER = 正常用户',
  `token` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'TOKEN',
  `invCode` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邀请码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of sd_user
-- ----------------------------
BEGIN;
INSERT INTO `sd_user` VALUES (1, '18888888888', '18888888888', '管理员', NULL, 0.00, 0.00, 0.00, 0.00, 0.00, '张三', NULL, NULL, NULL, '123123', 0, '2020-06-19 17:27:59', 0, 0, 'ADMIN', NULL, '1C3D');
COMMIT;

-- ----------------------------
-- Table structure for sd_user_address
-- ----------------------------
DROP TABLE IF EXISTS `sd_user_address`;
CREATE TABLE `sd_user_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL COMMENT '用户ID',
  `name` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '姓名',
  `tel` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '电话',
  `province` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '省份',
  `city` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '城市',
  `county` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '区/县',
  `addressDetail` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '详细地址',
  `areaCode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '地区编码',
  `postalCode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮政编码',
  `isDefault` int(1) DEFAULT NULL COMMENT '是否是默认地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for sd_user_bank
-- ----------------------------
DROP TABLE IF EXISTS `sd_user_bank`;
CREATE TABLE `sd_user_bank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL COMMENT '所属用户',
  `bankType` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行类型',
  `bankAccount` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行账号',
  `bankPhone` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '预留手机号',
  `bankPersionName` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '持卡人或机构名称',
  `bankOpenName` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '开户行名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for sd_user_order
-- ----------------------------
DROP TABLE IF EXISTS `sd_user_order`;
CREATE TABLE `sd_user_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL COMMENT '用户ID',
  `orderNo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单编号',
  `type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付类型',
  `money` decimal(20,2) DEFAULT NULL COMMENT '支付金额',
  `attach` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单标题',
  `bankCode` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行编码',
  `ip` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '客户IP',
  `sign` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '签名',
  `status` int(1) DEFAULT NULL COMMENT '0=未支付,1=支付完成',
  `createTime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for sd_withdrawal
-- ----------------------------
DROP TABLE IF EXISTS `sd_withdrawal`;
CREATE TABLE `sd_withdrawal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL COMMENT '用户ID',
  `money` decimal(20,2) DEFAULT NULL COMMENT '提现金额',
  `createTime` datetime DEFAULT NULL COMMENT '申请时间',
  `status` int(11) DEFAULT NULL COMMENT '0 = 未处理， 1 = 已处理， 2 = 已驳回',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

SET FOREIGN_KEY_CHECKS = 1;
